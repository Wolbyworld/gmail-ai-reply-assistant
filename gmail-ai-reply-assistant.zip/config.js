// This file is gitignored - contains secrets for backend auth
// DO NOT commit this file to version control

export const BACKEND_URL = 'https://luzia-backend-e1d9fb64f0d0.herokuapp.com';
export const BACKEND_SECRET = '49HzmWsbdQnsfexysS51bcu5HzOF6AJwhLK5K/YzmAk=';
